const valida = document.getElementById("valida");
const soma = document.getElementById("soma");
const numero1 = document.getElementById("numero1");
const maior = document.getElementById("maior");
const contrario = document.getElementById("contrario");
const menor = document.getElementById("menor");
function calcular() {
  var numero = document.getElementById("numero");

  // somar os 10 números
  var tsoma = 0;
  var x = 0;
  for (x=0; x<=9; x++) {
        tsoma += parseInt(numero.value[x]);
  }
  soma.textContent = "Soma dos 10: " + tsoma;

  // procurar quantos números 1
  var conta1 = 0;
  for (x=0; x<=9; x++) {
        if (parseInt(numero.value[x]) == 1 ) {
              conta1++;
        }
  }
  numero1.textContent = "Número 1: "+ conta1;

  // exibir o número ao contrário
  var y = "";
  for (x=9; x >=0 ; x--) {
        y += numero.value[x];
  }

  contrario.textContent = "Ao contrario" + y;

// calcular o maior valor
 tmaior = 0;
 var tmaior = 0;
  for (x=0 ; x<=9; x++) {
        if (parseInt(numero.value[x]) > tmaior) {
              tmaior = parseInt(numero.value[x]);
  }
}

maior.textContent = "Maior" + tmaior;
}

// calcular o menor valor
var tmenor = 10;
for (x=0 ; x<=9 x++) {
      if (parseInt(numero.value[x]) < tmenor) {
            tmenor = parseInt(numero.value[x]);
 }


menor.textContent = "menor" + tmenor;
}

valida.addEventListener("click", calcular);